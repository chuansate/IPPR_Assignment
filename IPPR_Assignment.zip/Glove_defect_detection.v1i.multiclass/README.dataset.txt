# Glove defect detection > 2022-04-20 5:39pm
https://universe.roboflow.com/aliar2456-gmail-com/glove-defect-detection

Provided by a Roboflow user
License: CC BY 4.0

